class Final_Metrics(object):
    def __init__(self, df_pymot_metric, df_reid_metric):
        self.df_pymot_metric = pymot_metric
        self.df_reid_metric = reid_metric
    




    
        
