wget -O checkpoints.zip "https://onedrive.live.com/download?cid=FBE7F410E8BD6803&resid=FBE7F410E8BD6803%21384&authkey=ANAFIjAXnh3R8RI"
unzip checkpoints.zip -d tracker/extractor
rm checkpoints.zip