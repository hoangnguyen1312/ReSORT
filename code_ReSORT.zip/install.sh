# sudo chmod u+x detector/install.sh
# sudo chmod u+x tracker/extractor/install.sh
detector/install.sh
tracker/extractor/install.sh
