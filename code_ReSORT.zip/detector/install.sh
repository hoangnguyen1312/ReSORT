wget -O weights.zip "https://onedrive.live.com/download?cid=FBE7F410E8BD6803&resid=FBE7F410E8BD6803%21382&authkey=AOdfWk_-5lQDspA"
unzip weights.zip -d detector
rm weights.zip